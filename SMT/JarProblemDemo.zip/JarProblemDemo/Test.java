import java.io.*;

public class Test{

  public static void main(String[] args){
    
    MyName myName = new MyName();
    
    System.out.println("My name is " + myName.getName());
    
  }

}