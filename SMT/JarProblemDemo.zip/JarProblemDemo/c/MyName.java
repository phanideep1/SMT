public class MyName{

  public MyName(){
    
  }
  
  public String getName(){
    return "Jack";
  }

}