package org.psnbtech;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BoardPanelTest {
	
	private Tetris tetris;
	private BoardPanel bpanel;
	public TileType tile;
	private Random random;
	private TileType tileType;
	private float gameSpeed;
	

	@Before
	public void setUp() throws Exception {
		tetris = new Tetris();
		bpanel = new BoardPanel(tetris);
		random = new Random();
		tile = TileType.values()[random.nextInt(Tetris.TYPE_COUNT)];
		tileType = TileType.TypeO;
		gameSpeed = 1.0f;
		tetris.setCurrentType(TileType.values()[random.nextInt(Tetris.TYPE_COUNT)]);
		tetris.setNextType(TileType.values()[random.nextInt(Tetris.TYPE_COUNT)]);
		tetris.setCurrentRow(1);
		tetris.setCurrentCol(5);
		tetris.setCurrentRotation(1);
		tetris.setLogicTimer(new Clock(gameSpeed));
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testIsValidAndEmpty() {
		//fail("Not yet implemented"); // TODO
		
		for(int i=0;i<=39;i++){
			tetris.updateGame();
		}
		
		boolean isValid = bpanel.isValidAndEmpty(tile, 7, 19, 0);
		
		assertEquals(false, isValid);
	}

	@Test
	public final void testAddPiece() {
		bpanel.addPiece(tileType, 4, 4, 1);
		//TileType t = bpanel.getTile(3, 4);
		System.out.println("tile : "+bpanel.getTile(3, 3));
		assertEquals(tileType, bpanel.getTile(4, 4));
	}

	@Test
	public final void testCheckLines() {
		//fail("Not yet implemented"); // TODO
		
		assertEquals(0, bpanel.checkLines());
		
	}

}
