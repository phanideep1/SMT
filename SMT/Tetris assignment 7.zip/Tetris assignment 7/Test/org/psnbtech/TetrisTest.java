package org.psnbtech;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TetrisTest {
	
	private Tetris tetris;
	private BoardPanel bpanel;
	public TileType tile;
	private Random random;
	private float gameSpeed;

	@Before
	public void setUp() throws Exception {
		tetris = new Tetris();
		bpanel = new BoardPanel(tetris);
		random = new Random();
		gameSpeed = 1.0f;
		tetris.setCurrentType(TileType.values()[random.nextInt(Tetris.TYPE_COUNT)]);
		tetris.setNextType(TileType.values()[random.nextInt(Tetris.TYPE_COUNT)]);
		tetris.setCurrentRow(1);
		tetris.setCurrentCol(5);
		tetris.setCurrentRotation(1);
		tetris.setLogicTimer(new Clock(gameSpeed));
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testUpdateGame() {
		//fail("Not yet implemented"); // TODO
				
		for(int i=0;i<=19;i++){
			tetris.updateGame();
		}
		
		
		assertEquals(0, tetris.getScore());
	}

}
