package assgn.smt.tetris.clock;

import assgn.smt.tetris.game.Clock;



public class ClockImpl implements IClockImp
{
	private ClockArch _arch;

    public ClockImpl (){
    }

	public void setArch(ClockArch arch){
		_arch = arch;
	}
	public ClockArch getArch(){
		return _arch;
	}

	/*
  	  Myx Lifecycle Methods: these methods are called automatically by the framework
  	  as the bricks are created, attached, detached, and destroyed respectively.
	*/	
	public void init(){
	    //TODO Auto-generated method stub
	}
	public void begin(){
		//TODO Auto-generated method stub
	}
	public void end(){
		//TODO Auto-generated method stub
	}
	public void destroy(){
		//TODO Auto-generated method stub
	}
	
	public Clock getClock(float cyclesPerSecond)
	{
		return new Clock(1.0f);
	}

	/*
  	  Implementation primitives required by the architecture
	*/
}