package assgn.smt.tetris;

import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.BoardPanel;

public interface IController {

	public BoardPanel getBoardPanel(GameControlImpl impl);
	
}
