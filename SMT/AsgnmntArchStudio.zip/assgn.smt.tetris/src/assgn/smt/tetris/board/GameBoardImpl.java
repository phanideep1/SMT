package assgn.smt.tetris.board;

import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.BoardPanel;



public class GameBoardImpl implements IGameBoardImp
{
	private GameBoardArch _arch;

    public GameBoardImpl (){
    }

	public void setArch(GameBoardArch arch){
		_arch = arch;
	}
	public GameBoardArch getArch(){
		return _arch;
	}

	/*
  	  Myx Lifecycle Methods: these methods are called automatically by the framework
  	  as the bricks are created, attached, detached, and destroyed respectively.
	*/	
	public void init(){
	    //TODO Auto-generated method stub
	}
	public void begin(){
		//TODO Auto-generated method stub
	}
	public void end(){
		//TODO Auto-generated method stub
	}
	public void destroy(){
		//TODO Auto-generated method stub
	}

	@Override
	public BoardPanel getBoardPanel(GameControlImpl impl) {
		// TODO Auto-generated method stub
		return new BoardPanel(impl);
	}

	/*
  	  Implementation primitives required by the architecture
	*/
}