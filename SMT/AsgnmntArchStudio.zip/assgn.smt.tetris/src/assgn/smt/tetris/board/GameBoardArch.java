package assgn.smt.tetris.board;


import assgn.smt.tetris.IController;
import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.*;
import edu.uci.isr.myx.fw.AbstractMyxSimpleBrick;
import edu.uci.isr.myx.fw.IMyxName;
import edu.uci.isr.myx.fw.MyxUtils;

public class GameBoardArch extends AbstractMyxSimpleBrick implements IController
{
    public static final IMyxName msg_IController = MyxUtils.createName("assgn.smt.tetris.IController");


	private IGameBoardImp _imp;

    public GameBoardArch (){
		_imp = getImplementation();
		if (_imp != null){
			_imp.setArch(this);
		} else {
			System.exit(1);
		}
	}
    
    protected IGameBoardImp getImplementation(){
        try{
			return new GameBoardImpl();    
        } catch (Exception e){
            System.err.println(e.getMessage());
            return null;
        }
    }

    public void init(){
        _imp.init();
    }
    
    public void begin(){
        _imp.begin();
    }
    
    public void end(){
        _imp.end();
    }
    
    public void destroy(){
        _imp.destroy();
    }
    
	public Object getServiceObject(IMyxName arg0) {
		if (arg0.equals(msg_IController)){
			return this;
		}        
		return null;
	}
  
    //To be imported: game
    public BoardPanel getBoardPanel (GameControlImpl impl)   {
		return _imp.getBoardPanel(impl);
    }    
}