package assgn.smt.tetris.control;


import assgn.smt.tetris.control.GameControlArch;

public interface IGameControlImp 
{

	/*
	  Getter and Setter of architecture reference
	*/
    public void setArch (GameControlArch arch);
	public GameControlArch getArch();
	
	/*
  	  Myx Lifecycle Methods: these methods are called automatically by the framework
  	  as the bricks are created, attached, detached, and destroyed respectively.
	*/	
	public void init();	
	public void begin();
	public void end();
	public void destroy();

	/*
  	  Implementation primitives required by the architecture
	*/
}