package assgn.smt.tetris.control;


import assgn.smt.tetris.IClock;
import assgn.smt.tetris.IController;
import assgn.smt.tetris.IInfo;

import edu.uci.isr.myx.fw.AbstractMyxSimpleBrick;
import edu.uci.isr.myx.fw.IMyxName;
import edu.uci.isr.myx.fw.MyxUtils;

public class GameControlArch extends AbstractMyxSimpleBrick
{
    public static final IMyxName msg_IController = MyxUtils.createName("assgn.smt.tetris.IController");
    public static final IMyxName msg_IInfo = MyxUtils.createName("assgn.smt.tetris.IInfo");
    public static final IMyxName msg_IClock = MyxUtils.createName("assgn.smt.tetris.IClock");

    public IController OUT_IController;
    public IInfo OUT_IInfo;
    public IClock OUT_IClock;

	private IGameControlImp _imp;

    public GameControlArch (){
		_imp = getImplementation();
		if (_imp != null){
			_imp.setArch(this);
		} else {
			System.exit(1);
		}
	}
    
    protected IGameControlImp getImplementation(){
        try{
			return new GameControlImpl();    
        } catch (Exception e){
            System.err.println(e.getMessage());
            return null;
        }
    }

    public void init(){
        _imp.init();
    }
    
    public void begin(){
        OUT_IController = (IController) MyxUtils.getFirstRequiredServiceObject(this,msg_IController);
        if (OUT_IController == null){
 			System.err.println("Error: Interface assgn.smt.tetris.IController returned null");
			return;       
        }
        OUT_IInfo = (IInfo) MyxUtils.getFirstRequiredServiceObject(this,msg_IInfo);
        if (OUT_IInfo == null){
 			System.err.println("Error: Interface assgn.smt.tetris.IInfo returned null");
			return;       
        }
        OUT_IClock = (IClock) MyxUtils.getFirstRequiredServiceObject(this,msg_IClock);
        if (OUT_IClock == null){
 			System.err.println("Error: Interface assgn.smt.tetris.IClock returned null");
			return;       
        }
        _imp.begin();
    }
    
    public void end(){
        _imp.end();
    }
    
    public void destroy(){
        _imp.destroy();
    }
    
	public Object getServiceObject(IMyxName arg0) {
		return null;
	}
}