package assgn.smt.tetris.info;


import assgn.smt.tetris.IInfo;
import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.*;
import edu.uci.isr.myx.fw.AbstractMyxSimpleBrick;
import edu.uci.isr.myx.fw.IMyxName;
import edu.uci.isr.myx.fw.MyxUtils;

public class InfoPanelArch extends AbstractMyxSimpleBrick implements IInfo
{
    public static final IMyxName msg_IInfo = MyxUtils.createName("assgn.smt.tetris.IInfo");


	private IInformationPanelImp _imp;

    public InfoPanelArch (){
		_imp = getImplementation();
		if (_imp != null){
			_imp.setArch(this);
		} else {
			System.exit(1);
		}
	}
    
    protected IInformationPanelImp getImplementation(){
        try{
			return new InfoPanelImpl();    
        } catch (Exception e){
            System.err.println(e.getMessage());
            return null;
        }
    }

    public void init(){
        _imp.init();
    }
    
    public void begin(){
        _imp.begin();
    }
    
    public void end(){
        _imp.end();
    }
    
    public void destroy(){
        _imp.destroy();
    }
    
	public Object getServiceObject(IMyxName arg0) {
		if (arg0.equals(msg_IInfo)){
			return this;
		}        
		return null;
	}
  
    //To be imported: game
    public SidePanel getPanel (GameControlImpl impl)   {
		return _imp.getPanel(impl);
    }    
}