package assgn.smt.tetris.info;



import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.SidePanel;
import assgn.smt.tetris.info.InfoPanelArch;

public interface IInformationPanelImp 
{

	/*
	  Getter and Setter of architecture reference
	*/
    public void setArch (InfoPanelArch arch);
	public InfoPanelArch getArch();
	
	/*
  	  Myx Lifecycle Methods: these methods are called automatically by the framework
  	  as the bricks are created, attached, detached, and destroyed respectively.
	*/	
	public void init();	
	public void begin();
	public void end();
	public void destroy();

	/*
  	  Implementation primitives required by the architecture
	*/
  
    //To be imported: game
    public SidePanel getPanel (GameControlImpl impl)  ;        
}