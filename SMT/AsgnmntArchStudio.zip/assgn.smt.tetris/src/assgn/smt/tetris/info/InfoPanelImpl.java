package assgn.smt.tetris.info;

import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.SidePanel;



public class InfoPanelImpl implements IInformationPanelImp
{
	private InfoPanelArch _arch;

    public InfoPanelImpl (){
    }

	public void setArch(InfoPanelArch arch){
		_arch = arch;
	}
	public InfoPanelArch getArch(){
		return _arch;
	}

	/*
  	  Myx Lifecycle Methods: these methods are called automatically by the framework
  	  as the bricks are created, attached, detached, and destroyed respectively.
	*/	
	public void init(){
	    //TODO Auto-generated method stub
	}
	public void begin(){
		//TODO Auto-generated method stub
	}
	public void end(){
		//TODO Auto-generated method stub
	}
	public void destroy(){
		//TODO Auto-generated method stub
	}

	@Override
	public SidePanel getPanel(GameControlImpl impl) {
		// TODO Auto-generated method stub
		return new SidePanel(impl);
	}

	/*
  	  Implementation primitives required by the architecture
	*/
}