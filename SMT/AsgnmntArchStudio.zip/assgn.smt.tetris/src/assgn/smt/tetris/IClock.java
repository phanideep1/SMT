package assgn.smt.tetris;

import assgn.smt.tetris.game.Clock;

public interface IClock {

	public Clock getClock(float cyclesPerSecond);
	
}
