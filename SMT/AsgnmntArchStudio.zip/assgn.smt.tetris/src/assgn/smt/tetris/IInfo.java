package assgn.smt.tetris;

import assgn.smt.tetris.control.GameControlImpl;
import assgn.smt.tetris.game.SidePanel;

public interface IInfo {
	
	public SidePanel getPanel(GameControlImpl impl);

}
