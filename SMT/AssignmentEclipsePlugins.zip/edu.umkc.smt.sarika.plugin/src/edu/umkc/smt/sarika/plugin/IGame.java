package edu.umkc.smt.sarika.plugin;



public interface IGame {

	public void getTetris();
	
}
