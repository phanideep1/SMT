public class A{

  public static void main(String[] args){
    B b = new B();
    b.greet();

    System.out.println("");
  }

}