import java.io.*;

public class C{

  public void sayHello(){
    System.out.println("How are you?");
  }

}