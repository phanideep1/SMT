public class B{

  public void greet(){
    C c = new C();
    c.sayHello();
  }

}