package tetrisarch;

import java.awt.Graphics;


public interface IBoardPanel {
	public void clear();
	public boolean isValidAndEmpty(TileType type, int x, int y, int rotation);
	public void addPiece(TileType type, int x, int y, int rotation);
	public int checkLines();
	public void paintComponent(Graphics g);
	
	
}
