package tetrisarch;

import java.awt.Graphics;

import org.psnbtech.Tetris;

public interface ISidePanel {
	public SidePanel(Tetris tetris);
	public void paintComponent(Graphics g);
	
	
}
