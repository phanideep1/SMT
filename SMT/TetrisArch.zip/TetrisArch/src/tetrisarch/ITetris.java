package tetrisarch;

import java.awt.event.KeyEvent;

import org.psnbtech.TileType;

public interface ITetris {
	public void keyPressed(KeyEvent e);
	public void keyReleased(KeyEvent e);
	public boolean isPaused();
	public boolean isGameOver();
	public boolean isNewGame();
	public int getScore();
	public int getLevel();
	public TileType getPieceType();
	public TileType getNextPieceType();
	public int getPieceCol();
	public int getPieceRow();
	public int getPieceRotation();
}
